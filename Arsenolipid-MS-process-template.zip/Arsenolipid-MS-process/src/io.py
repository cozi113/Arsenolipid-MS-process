from pathlib import Path
import numpy as np
import pandas as pd
import pymzml
import matplotlib.pyplot as plt

def read_run(mzml_path: str):
    return pymzml.run.Reader(mzml_path)

def export_tic_bpc(mzml_path: str, out_dir="data/processed", prefix=None):
    run = read_run(mzml_path)
    times, tic, bpc = [], [], []
    for spec in run:
        if getattr(spec, "ms_level", 1) == 1 and getattr(spec, "i", None):
            times.append(spec.scan_time_in_minutes())
            intens = np.array(spec.i)
            tic.append(intens.sum())
            bpc.append(intens.max())
    df = pd.DataFrame({"time_min": times, "TIC": tic, "BPC": bpc})
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    name = prefix or Path(mzml_path).stem
    csv_path = Path(out_dir) / f"{name}_tic_bpc.csv"
    df.to_csv(csv_path, index=False)

    for col in ["TIC", "BPC"]:
        plt.figure()
        plt.plot(df["time_min"], df[col])
        plt.xlabel("Time (min)")
        plt.ylabel(col)
        plt.title(f"{name} {col}")
        plt.tight_layout()
        plt.savefig(Path(out_dir) / f"{name}_{col}.png", dpi=150)
        plt.close()
    return df
