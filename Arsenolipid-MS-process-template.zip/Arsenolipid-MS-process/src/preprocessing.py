import numpy as np
import pandas as pd
import pymzml
from pathlib import Path

def bin_peaks(mzml_path, mz_bin=0.01, rt_bin=0.05, out_dir="data/interim"):
    run = pymzml.run.Reader(mzml_path)
    rows = []
    for spec in run:
        if getattr(spec, "ms_level", 1) == 1 and getattr(spec, "peaks_count", 0) > 0:
            rt = spec.scan_time_in_minutes()
            # try centroided peaks if available
            try:
                iterator = spec.peaks("centroided")
            except Exception:
                iterator = spec.peaks("raw")
            for mz, intensity in iterator:
                rows.append((rt, mz, intensity))
    df = pd.DataFrame(rows, columns=["rt_min","mz","intensity"])
    if df.empty:
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        out = Path(out_dir)/f"{Path(mzml_path).stem}_binned.csv"
        df.to_csv(out, index=False)
        return df
    df["mz_bin"] = (df["mz"]/mz_bin).round().astype(float) * mz_bin
    df["rt_bin"] = (df["rt_min"]/rt_bin).round().astype(float) * rt_bin
    agg = df.groupby(["rt_bin","mz_bin"], as_index=False)["intensity"].max()
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    out = Path(out_dir)/f"{Path(mzml_path).stem}_binned.csv"
    agg.to_csv(out, index=False)
    return agg
