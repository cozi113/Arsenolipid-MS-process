import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegressionCV
from sklearn.metrics import classification_report
from pathlib import Path

def train_classify(feature_csv="data/processed/feature_table.csv", label_csv="data/labels.csv", out_dir="data/processed"):
    X = pd.read_csv(feature_csv, index_col=0)
    if X.empty:
        raise ValueError("Feature table is empty. Did you generate binned tables and merge them?")
    ydf = pd.read_csv(label_csv)  # columns: sample,label
    y = ydf.set_index("sample").loc[X.index, "label"]
    scaler = StandardScaler(with_mean=False)
    Xs = scaler.fit_transform(X)
    clf = LogisticRegressionCV(cv=5, max_iter=5000, n_jobs=-1)
    clf.fit(Xs, y)
    yhat = clf.predict(Xs)
    report = classification_report(y, yhat, output_dict=True)
    Path(out_dir).mkdir(parents=True, exist_ok=True)
    pd.DataFrame(report).to_csv(f"{out_dir}/clf_report.csv")
    # feature weights (binary/single-class focus)
    import numpy as np
    coef = getattr(clf, "coef_", None)
    if coef is not None:
        import numpy as np
        coefs = pd.Series(coef.ravel(), index=X.columns).sort_values(ascending=False)
        coefs.head(200).to_csv(f"{out_dir}/top_features.csv", header=["weight"])
    return clf
