import pandas as pd
from pathlib import Path
from glob import glob

def merge_binned_tables(interim_dir="data/interim", out_path="data/processed/feature_table.csv"):
    files = glob(f"{interim_dir}/*_binned.csv")
    if not files:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame().to_csv(out_path)
        return pd.DataFrame()
    tables = []
    for f in files:
        sname = Path(f).stem.replace("_binned","")
        t = pd.read_csv(f)
        t["sample"] = sname
        tables.append(t)
    df = pd.concat(tables, ignore_index=True)
    if df.empty:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame().to_csv(out_path)
        return pd.DataFrame()
    df["feature"] = df["rt_bin"].astype(str) + "|" + df["mz_bin"].astype(str)
    mat = df.pivot_table(index="sample", columns="feature", values="intensity", fill_value=0, aggfunc="max")
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    mat.to_csv(out_path)
    return mat
