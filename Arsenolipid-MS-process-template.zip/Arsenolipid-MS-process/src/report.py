import json, shutil
from pathlib import Path

def export_summary_json(out_dir="data/processed", docs_dir="docs/assets"):
    Path(docs_dir).mkdir(parents=True, exist_ok=True)
    for fn in ["top_features.csv","clf_report.csv"]:
        src = Path(out_dir)/fn
        if src.exists():
            shutil.copy(src, Path(docs_dir)/fn)
    summary = {"assets": ["top_features.csv","clf_report.csv"]}
    with open(Path(docs_dir)/"summary.json","w") as f:
        json.dump(summary, f, indent=2)
