# Pipeline

1. Read mzML → export TIC/BPC
2. Level-1 binning on (RT × m/z) → sample-wise binned tables
3. Merge into sample × feature matrix
4. ML training (LogRegCV by default; can swap to RF/XGBoost)
5. Export CSV/JSON to docs/assets for the site

!!! tip
    Convert vendor formats to mzML with ProteoWizard `msconvert` beforehand.
